# GPU 3 架构搜索与论文同步

## 查看每次实验的预测曲线

在浏览器打开项目根目录的 **`预测结果浏览.html`**，可以按数据集、预测长度、模型和种子筛选；点击总览图片进入各变量的详细曲线和PDF下载。

每次已经完成测试的实验，其图片保存在该运行目录的 `figures/predictions/`：

- `overview.png`：固定第一个测试窗口的变量总览。
- `channel_006.png/.pdf`等：按原始变量编号命名，每张包含固定首、中、末三个测试窗口。
- `index.html`：这次实验的图片详情。
- `plot_complete.json`：图的来源指纹、变量编号及窗口编号。

图示包含最近96步历史、真实未来值、预测中位数、50%和90%预测区间，使用原始量纲。高维数据集展示预测数组中预先均匀选出的至多8个变量；图示不覆盖所有变量或全部滑动窗口，完整测试指标仍覆盖全部变量和窗口。仅做验证筛选、尚未测试的运行不生成测试预测图。

CPU批量补图入口（可以重复运行，源数组及渲染版本一致时复用已有图片）：

```bash
CUDA_VISIBLE_DEVICES='' MPLCONFIGDIR=/tmp/hadt_prediction_mpl \
  /home/dingjunjie/anaconda3/envs/djjTF/bin/python scripts/plot_run_forecasts.py --workers 2
```

后续每次测试完成时，论文导出器会在CPU上自动生成这次实验的曲线并更新浏览入口；已有图片按源数据和绘图脚本指纹复用。

浏览文件和原始图片依赖服务器的 `outputs/` 目录；该目录仍不上传Git。浏览入口属于本地生成结果。

本轮使用 `/home/dingjunjie/anaconda3/envs/djjTF/bin/python`。最初仅用物理GPU 3；用户随后授权检测并利用空闲GPU 0/1/2/3，训练配置和数据协议保持不变。

## 自动检测空闲显卡并行运行

常驻调度器为 `scripts/gpu_queue_scheduler.py`，默认每30秒查询一次显卡。额外显卡需要连续两次检测满足：利用率不高于10%、显存占用不高于1024 MiB、可用显存至少12 GiB、没有其他非桌面计算进程。不会终止其他人的进程。GPU3保留现有授权的基础运行槽，也受至少12 GiB可用显存限制。

没有额外空闲卡时，现有GPU3队列继续运行；首次有额外卡满足条件时，等待当前实验完成并让它的论文导出子进程正常结束，再切换到多卡调度。每张卡每次分配一个独立实验。继承式GPU锁和逐实验锁防止重启期间重复分配。每个工作进程只暴露分配到的GPU UUID，程序内统一使用cuda:0。

查看实时状态：

```bash
cat outputs/architecture_study/scheduler_state.json
tail -f outputs/architecture_study/scheduler.log
```

`scheduler_state.json`含当前GPU占用、最近检测时间、空闲计数、活动GPU与具体实验。`watching_legacy`表示保持原GPU3进程并监测其他卡，`running_parallel`表示已接管队列；并行卡数由实际空闲情况决定。`attention_required`表示某项运行或论文发布失败，调度器停止分配新任务并保留错误，不冒充已完成。

启动或恢复（调度器锁会阻止重复启动）：

```bash
CUDA_VISIBLE_DEVICES='' OMP_NUM_THREADS=4 \
  /home/dingjunjie/anaconda3/envs/djjTF/bin/python -u scripts/gpu_queue_scheduler.py --interval 30
```

只读查询、不启动训练：`python scripts/gpu_queue_scheduler.py --once`（建议使用上述djjTF解释器）。

工作进程日志与状态位于 `outputs/architecture_study/parallel_workers/<任务ID>/`。新运行目录中的 `execution.json`记录物理显卡、UUID、是否复用了训练检查点及调度器指纹；历史签名不重写。`execution_policy.json`记录新的资源授权。论文发布持有独占锁，完成记录提交使用共享锁，因此并行训练期间独立核验读取的是一致快照。图片与LaTeX仍由同一个串行导出器更新。

接管后 `worker.pid`指向调度器，实际训练PID见`scheduler_state.json`；`scheduler.pid.json`也记录调度器PID。不要删除运行中的GPU锁或实验锁文件。调度器意外退出时，已经开始的子任务仍可完成；重启会识别仍存活的工作进程。

## 实验顺序

1. ETTh1、H96、seed2024，预先固定的12个候选各筛选8轮。比较Transformer、MLP、膨胀CNN、CNN+Transformer、直接输出等组合，另有D64与学习率3e-4的联合变体。
2. 验证损失前三名加原模型，各用seed2024/2025/2026、最多30轮复核。按**平均验证集pinball**冻结最佳候选。此时尚未用测试集决定配置。
3. 冻结后评估选中模型、原模型及Linear-NQ。七数据集×四预测长度(96/192/336/720)×三种子；选中模型与对照相同时去重。先做ETTh1/ETTh2，再做新增数据集。完整矩阵可能耗时较长，待运行项不作为已有结果。

每次运行保留配置、数据/代码/检查点SHA256、最佳验证检查点、训练曲线和全部测试窗口/变量的指标。示例预测固定为测试集首、中、末窗口，不能用图示窗口替代全测试指标。

首轮短暂运行归档于`outputs/architecture_study_pilot_20261105/`，其目录中保存的源路径是归档前路径；不参与新实验统计。新版本改用与标准Conv1d在CPU双精度数值和梯度上对照一致的unfold+linear卷积实现，绕开当前硬件/确定性cuDNN对膨胀卷积的慢内核。独立代码审查发现的配置冻结、缓存与论文证据绑定缺口已修复并有回归测试。

## 查看实时状态

```bash
cat outputs/architecture_study/current_job.json
cat HADT_NQ_ICCRD2027_LaTeX/results/architecture_status.json
tail -f outputs/architecture_study/worker.log
```

主进程PID保存在`outputs/architecture_study/worker.pid`，单独会话运行，终端断开不会自动停止。`failure.json`表示发生错误，恢复时会清除旧错误。`progress.json`记录测试矩阵进度；筛选与复核状态见论文目录的`architecture_status.json`。启动锁阻止重复工作进程。

## 恢复队列

仅在原进程已退出后执行，完成且溯源匹配的单次实验会复用；中断的单次训练从头重新训练，而非恢复优化器随机状态。

```bash
CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=3 OMP_NUM_THREADS=4 \
  MPLCONFIGDIR=/tmp/hadt_architecture_mpl \
  /home/dingjunjie/anaconda3/envs/djjTF/bin/python -u scripts/run_architecture_study.py
```

代码、配置或数据改变后会拒绝混用旧目录。需要新的实验命名空间，而不是删除原始证据。

## 论文与结果

每次完成实验后自动调用`export_architecture_study.py`，更新：

冻结选型、首次测试完成及每新增完整三种子组时，会自动调用独立核验脚本；核验失败则停止队列，不发布未经核验的新PDF。

- `results/architecture_section.tex`：搜索协议、候选表、完成的三种子测试表和已测结论。
- `results/architecture_records.json`、`architecture_aggregates.csv`、`architecture_status.json`：原始记录、完整组均值/样本标准差、进度。
- `figures/architecture_*.pdf/.png`：筛选、验证学习曲线、选中结构与固定测试窗口预测图。
- `main.pdf`：通过本地Tectonic重新编译。
- `configs/selected_architecture.json`：冻结后写入选中候选及其训练配置。

原论文默认模型的历史结果和结构图保留，选中变体另行标明。局部验证搜索无法证明全局最优；测试迁移不改善时也应如实保留。直接输出模型胜出不能据此宣称形变注意力有效或组件具有新颖性。

独立核验当前已完成记录（CPU）：

```bash
CUDA_VISIBLE_DEVICES='' /home/dingjunjie/anaconda3/envs/djjTF/bin/python \
  scripts/validate_architecture_study.py
```

核验包括数据与检查点哈希、训练前缀scaler、划分边界、最佳验证轮次、固定图示真值、排序、完整种子统计、选型冻结指纹；不会重新推理所有完整测试集。训练时不应同时手动运行导出器，因为它和工作进程会写相同的论文文件。
