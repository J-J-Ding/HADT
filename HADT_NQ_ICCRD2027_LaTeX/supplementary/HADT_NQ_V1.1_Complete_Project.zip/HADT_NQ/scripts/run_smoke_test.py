from utils.smoke_test import run_smoke_test

if __name__ == "__main__":
    run_smoke_test()
