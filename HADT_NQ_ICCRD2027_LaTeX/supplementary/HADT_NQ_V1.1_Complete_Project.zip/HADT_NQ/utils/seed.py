import os
import random
import numpy as np
import torch


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    # Reproducibility-first settings. May reduce peak performance slightly.
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
