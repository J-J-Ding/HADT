from pathlib import Path
import torch


def save_checkpoint(path, model, optimizer, epoch, best_val_loss, config):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "model_state": model.state_dict(),
            "optimizer_state": optimizer.state_dict(),
            "epoch": int(epoch),
            "best_val_loss": float(best_val_loss),
            "config": config,
        },
        path,
    )


def load_checkpoint(path, model, map_location="cpu"):
    checkpoint = torch.load(
        path, map_location=map_location, weights_only=False
    )
    model.load_state_dict(checkpoint["model_state"])
    return checkpoint
