# HADT-NQ: Independent Research Codebase

**Horizon-Adaptive Deformable Transformer with Non-Crossing Quantile Regression**

This is a standalone PyTorch research project. It does not depend on DBFI-Net or its training framework.

## 1. Main design

- Input: multivariate history `x: [B, L, C]`
- Output: seven conditional quantiles `q: [B, H, C, 7]`
- Quantiles: `[0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95]`
- Backbone: overlapping patch embedding + temporal Transformer encoder
- Decoder: horizon-conditioned deformable sparse attention
- Output head: median-anchored cumulative Softplus, structurally non-crossing
- Loss: multi-quantile pinball loss
- Data scaling: StandardScaler fitted on training rows only; model-side RevIN is reversible and has no affine parameters.

## 2. Project structure

```text
HADT_NQ/
├── configs/
│   └── default.yaml
├── data_provider/
│   ├── csv_dataset.py
│   ├── data_factory.py
│   └── scaler.py
├── engine/
│   ├── checkpoint.py
│   ├── evaluator.py
│   └── trainer.py
├── experiments/
│   └── runner.py
├── losses/
│   └── quantile_loss.py
├── metrics/
│   └── interval_metrics.py
├── models/
│   ├── hadt_nq.py
│   ├── horizon_deformable.py
│   ├── noncrossing_head.py
│   ├── patch_embedding.py
│   ├── revin.py
│   └── transformer_encoder.py
├── scripts/
│   ├── run_experiment.sh
│   └── run_smoke_test.py
├── tests/
│   ├── test_data.py
│   └── test_model.py
├── utils/
│   ├── config.py
│   ├── logger.py
│   ├── seed.py
│   └── smoke_test.py
├── main.py
├── PROJECT_SPEC.md
└── requirements.txt
```

## 3. Environment

Recommended:
- Python 3.10 or 3.11
- PyTorch 2.2+
- CUDA-enabled PyTorch if training on NVIDIA GPU

Install:

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
```

## 4. Dataset placement

Place CSV files in `./dataset/` by default:

```text
dataset/
├── ETTh1.csv
├── ETTh2.csv
├── ETTm1.csv
├── ETTm2.csv
├── electricity.csv
├── traffic.csv
└── weather.csv
```

The file names can be changed in `configs/default.yaml`.

Each CSV must contain:
- one timestamp column (default name: `date`);
- numeric feature columns;
- no missing/non-finite values in selected numeric columns.

The timestamp column is excluded from `C`. All remaining numeric columns are used in multivariate (`M`) mode. The loader reports the detected feature names and `C`. If a dataset has a different timestamp column, update `data.time_column`.

## 5. Data split and window semantics

Default split follows the study's existing protocol: ETT datasets use chronological 60% / 20% / 20%; Electricity, Traffic, and Weather use 70% / 10% / 20%. The scaler is fitted only on the training portion.

For a target start index `t`:
- input is `data[t-L:t]`;
- target is `data[t:t+H]`.

Validation targets begin at the validation boundary; their input context may use the immediately preceding training history. Test targets begin at the test boundary; their input context may use preceding observed history. No target window crosses its own split boundary.

If a different split protocol is required for a particular benchmark, change the ratios in the YAML and record that choice in the paper.

## 6. Hyperparameters

The default main-experiment configuration is:
- `L=336`
- `H in [96, 192, 336, 720]`
- `P=16`, `S=8`
- `D=128`, `heads=8`, `encoder_layers=3`, `d_ff=256`
- dropout `0.1`
- sampling points `K=auto`
- maximum offset `1.5` Patch tokens
- seven quantiles as listed above

`C` is detected from the CSV. `N`, `K`, and `head_dim` are derived, not manually duplicated.

For `L=336`, `P=16`, `S=8`:
`N=floor((336-16)/8)+1=41`, and the default auto rule gives `K=8`.

## 7. Run commands

### Smoke test (no dataset needed)

```bash
python main.py --mode smoke
```

This checks:
- output shapes;
- strict quantile ordering;
- sampling positions within valid bounds;
- gradient flow to the offset generator;
- multiple channel counts and prediction horizons.

### One experiment

```bash
python main.py --mode single --dataset ETTh1 --pred_len 96 --seed 2024

# PowerShell uses the same command syntax.
```

### Full experiment matrix

```bash
python main.py --mode experiment
```

The full matrix is `datasets × horizons × seeds`. It can be expensive. Run one experiment first, inspect the logs, then launch the matrix.

### Run tests

```bash
python -m unittest discover -s tests -v
```

## 8. Memory controls

- Training samples a random subset of variables only when `C > channel_sample_size`. The same channel indices are used for `x` and `y`.
- Evaluation visits all variables in channel chunks.
- The deformable decoder processes the horizon dimension in chunks.
- Optional activation checkpointing recomputes each decoder chunk during backward to reduce saved activation memory.

These are memory-management choices. They do not change the mathematical output shape or the shared channel-independent model parameters.

## 9. Output artifacts

Each run writes to:

```text
outputs/HADT_NQ/<dataset>/H<pred_len>/seed<seed>/
```

Typical outputs:
- `train.log`
- `best_checkpoint.pt`
- `resolved_config.json`
- `metrics.json`
- `horizon_metrics.csv`

The experiment runner also writes `outputs/HADT_NQ/summary.csv`.

## 10. Important methodological notes

1. Non-crossing is guaranteed by the output parameterization; calibrated coverage is **not** guaranteed.
2. PICP is marginal elementwise coverage pooled over forecast windows and variables. It is not simultaneous joint coverage of the full multivariate vector.
3. The model is channel-independent with shared weights. It does not explicitly model cross-variable dependence.
4. Use validation data for model selection and hyperparameter decisions. Do not tune on test metrics.
5. Report multiple seeds and mean ± standard deviation.
6. The default values are a reasoned starting configuration, not a claim of globally optimal hyperparameters.


## 11. Inspect a dataset before training

```bash
python scripts/inspect_dataset.py --csv dataset/ETTh1.csv --time_column date
```

This reports row count, detected variable count, feature names, and finite-value status.
